package com.example.riskbubble

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.*

class MainActivity : Activity() {

    private lateinit var key: EditText
    private lateinit var bal: EditText
    private lateinit var risk: EditText
    private lateinit var csFx: EditText
    private lateinit var csGold: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = getSharedPreferences("risk", Context.MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun label(t: String) = TextView(this).apply { text = t; textSize = 14f; setPadding(0, pad / 2, 0, 0) }
        fun field(hint: String, saved: String, type: Int) = EditText(this).apply {
            this.hint = hint; setText(saved); inputType = type; layoutDirection = View.LAYOUT_DIRECTION_LTR
        }

        key = field("sk-ant-...", p.getString("key", "") ?: "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        bal = field("1000", p.getString("bal", "") ?: "", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        risk = field("1", p.getString("risk", "1") ?: "1", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)

        csFx = field("100000", p.getString("csfx", "100000") ?: "100000", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        csGold = field("100", p.getString("csgold", "100") ?: "100", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)

        root.addView(TextView(this).apply { text = "Risk Bubble"; textSize = 24f })
        root.addView(label("کلید API (از console.anthropic.com)")); root.addView(key)
        root.addView(label("موجودی حساب")); root.addView(bal)
        root.addView(label("درصد ریسک (٪)")); root.addView(risk)
        root.addView(label("اندازه‌ی هر لات فارکس (طبق بروکرت، معمولاً 100000)")); root.addView(csFx)
        root.addView(label("اندازه‌ی هر لات طلا (اونس، معمولاً 100)")); root.addView(csGold)
        root.addView(Button(this).apply {
            text = "شروع حباب"
            setOnClickListener { start(p) }
        })
        root.addView(TextView(this).apply {
            text = "بعد از شروع، یه حباب کوچیک رو صفحه میاد. متاتریدر رو باز کن، روی حباب بزن، و حجم رو می‌بینی. نگه داشتن طولانی روی حباب اون رو می‌بنده."
            textSize = 13f; setPadding(0, pad, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun start(p: android.content.SharedPreferences) {
        p.edit().putString("key", key.text.toString().trim())
            .putString("bal", bal.text.toString().trim())
            .putString("risk", risk.text.toString().trim())
            .putString("csfx", csFx.text.toString().trim())
            .putString("csgold", csGold.text.toString().trim()).apply()

        if (p.getString("key", "").isNullOrEmpty()) {
            Toast.makeText(this, "اول کلید API رو وارد کن", Toast.LENGTH_LONG).show(); return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "اجازه‌ی نمایش روی اپ‌های دیگه رو روشن کن و برگرد", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 1)
    }

    @Deprecated("simple approach")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java).putExtra("code", resultCode).putExtra("data", data)
            startForegroundService(i)
            finish()
        }
    }
}
