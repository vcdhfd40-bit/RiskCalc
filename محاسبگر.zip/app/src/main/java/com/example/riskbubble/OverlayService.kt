package com.example.riskbubble

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.Base64
import android.view.*
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class OverlayService : Service() {

    // مدل خوندن عکس. اگه خواستی عوضش کنی، فقط همین اسم رو عوض کن.
    private val MODEL = "claude-haiku-5-5"

    private val PROMPT = """این اسکرین‌شات از اپ متاتریدر (MT4/MT5) است و یه سفارش یا معامله توشه. اطلاعات رو بخون و فقط یه JSON بده، بدون هیچ متن دیگه:
{"symbol":string|null,"side":"buy"|"sell"|null,"entry":number|null,"sl":number|null,"tp":number|null,"lots":number|null,"balance":number|null,"category":"forex"|"gold"|"crypto"|"stock"|"index"|"other","quote":string|null}
entry قیمت ورود یا قیمت سفارش است. sl همان Stop Loss و tp همان Take Profit است. lots حجم نوشته‌شده است. quote ارز دوم جفت‌ارز است (مثلا USD برای EURUSD، JPY برای USDJPY). اگه چیزی تو عکس دیده نمی‌شه، null بذار و حدس نزن. عددها رو بدون جداکننده‌ی هزارگان بده."""

    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private var bubble: TextView? = null
    private var panel: TextView? = null
    private var reader: ImageReader? = null
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i == null || bubble != null) return START_NOT_STICKY
        startFg()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val code = i.getIntExtra("code", 0)
        @Suppress("DEPRECATION")
        val data = i.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(code, data)
        projection = mp
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, h)

        val dm = resources.displayMetrics
        val r = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
        reader = r
        vd = mp.createVirtualDisplay(
            "risk", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, h
        )
        addBubble()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val ch = "risk"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Risk Bubble", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch).setContentTitle("Risk Bubble فعاله")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun params(w: Int, hgt: Int) = WindowManager.LayoutParams(
        w, hgt, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun addBubble() {
        val b = TextView(this).apply {
            text = "حجم؟"; setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#0F6B4F")) }
        }
        val lp = params(dp(58), dp(58)).apply { x = dp(8); y = dp(240) }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false; var down = 0L
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; down = System.currentTimeMillis() }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - sx) > dp(6) || abs(e.rawY - sy) > dp(6)) moved = true
                    lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(b, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    if (System.currentTimeMillis() - down > 700) stopSelf() else capture()
                }
            }
            true
        }
        wm.addView(b, lp)
        bubble = b
    }

    private fun show(msg: String) {
        panel?.let { runCatching { wm.removeView(it) } }
        val t = TextView(this).apply {
            text = msg; setTextColor(Color.WHITE); textSize = 16f
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(Color.parseColor("#EE14201B")) }
            setOnClickListener { runCatching { wm.removeView(this) }; panel = null }
        }
        val lp = params(dp(300), WindowManager.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(90)
        }
        wm.addView(t, lp)
        panel = t
    }

    private fun capture() {
        panel?.let { runCatching { wm.removeView(it) }; panel = null }
        bubble?.visibility = View.INVISIBLE
        h.postDelayed({ grab(0) }, 350)
    }

    private fun grab(n: Int) {
        val r = reader ?: return
        val img = r.acquireLatestImage()
        if (img == null) {
            if (n < 12) h.postDelayed({ grab(n + 1) }, 150)
            else { bubble?.visibility = View.VISIBLE; show("صفحه رو نتونستم بگیرم. دوباره بزن.") }
            return
        }
        val p = img.planes[0]
        val w = p.rowStride / p.pixelStride
        val full = Bitmap.createBitmap(w, img.height, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(p.buffer)
        img.close()
        val shot = Bitmap.createBitmap(full, 0, 0, r.width, r.height)
        bubble?.visibility = View.VISIBLE
        show("دارم می‌خونم...")

        val k = min(1f, 1600f / max(shot.width, shot.height))
        val small = Bitmap.createScaledBitmap(shot, (shot.width * k).toInt(), (shot.height * k).toInt(), true)
        val out = ByteArrayOutputStream()
        small.compress(Bitmap.CompressFormat.JPEG, 85, out)
        val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)

        thread {
            val msg = try { analyze(ask(b64)) } catch (e: Exception) { "نشد: ${e.message}" }
            h.post { show(msg) }
        }
    }

    private fun ask(b64: String): String {
        val p = getSharedPreferences("risk", Context.MODE_PRIVATE)
        val img = JSONObject().put("type", "image").put(
            "source", JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", b64)
        )
        val txt = JSONObject().put("type", "text").put("text", PROMPT)
        val body = JSONObject().put("model", MODEL).put("max_tokens", 400).put(
            "messages", JSONArray().put(JSONObject().put("role", "user").put("content", JSONArray().put(img).put(txt)))
        )
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.setRequestProperty("x-api-key", p.getString("key", ""))
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("content-type", "application/json")
        c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 40000
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val resp = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code != 200) throw Exception("خطای سرور $code (کلید API یا اینترنت رو چک کن)")
        return JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text")
    }

    private fun f(x: Double, d: Int = 2) = String.format(Locale.US, "%.${d}f", x)

    private fun analyze(raw: String): String {
        val d = JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1))
        fun num(k: String) = if (!d.has(k) || d.isNull(k)) Double.NaN else d.optDouble(k, Double.NaN)

        val p = getSharedPreferences("risk", Context.MODE_PRIVATE)
        var bal = p.getString("bal", "")?.toDoubleOrNull() ?: Double.NaN
        if (bal.isNaN() || bal <= 0) bal = num("balance")
        val rp = p.getString("risk", "1")?.toDoubleOrNull() ?: 1.0
        val en = num("entry"); val sl = num("sl"); val tp = num("tp"); val lots = num("lots")

        if (en.isNaN() || sl.isNaN()) return "قیمت ورود یا حد ضرر تو صفحه پیدا نشد. صفحه‌ی سفارش (با حد ضرر) رو باز کن و دوباره بزن."
        if (bal.isNaN() || bal <= 0) return "موجودی رو تو برنامه وارد کن."
        if (en == sl) return "قیمت ورود و حد ضرر یکی خونده شد."

        val cat = d.optString("category", "other")
        val cs = when (cat) {
            "forex" -> p.getString("csfx", "")?.toDoubleOrNull()?.takeIf { it > 0 } ?: 100000.0
            "gold" -> p.getString("csgold", "")?.toDoubleOrNull()?.takeIf { it > 0 } ?: 100.0
            else -> 1.0
        }
        val unit = if (cat == "forex" || cat == "gold") "لات" else "واحد"
        val buy = sl < en
        val dist = abs(en - sl)
        val riskAmt = bal * rp / 100
        val size = riskAmt / dist / cs

        val sb = StringBuilder()
        sb.append(if (buy) "خرید" else "فروش")
        if (!d.isNull("symbol")) sb.append(" ").append(d.optString("symbol"))
        sb.append("\nحجم ورود: ").append(f(size, if (size >= 1) 2 else 4)).append(" ").append(unit)
        sb.append("\nریسک: ").append(f(rp)).append("٪ = ").append(f(riskAmt))
        if (!lots.isNaN() && lots > 0) {
            val ar = lots * cs * dist / bal * 100
            sb.append("\nبا حجم فعلی‌ت (").append(f(lots, 4)).append(") ریسکت ").append(f(ar)).append("٪")
            if (ar > rp * 1.05) sb.append(" ← بیشتر از حدته")
        }
        if (!tp.isNaN() && (if (buy) tp > en else tp < en)) sb.append("\nریسک به ریوارد: 1 : ").append(f(abs(tp - en) / dist))
        val q = d.optString("quote", "")
        if (cat == "forex" && q.isNotEmpty() && q != "USD" && q != "null") sb.append("\n(ارز دوم $q است، پس مبلغ ریسک تقریبیه)")
        return sb.toString()
    }

    override fun onDestroy() {
        panel?.let { runCatching { wm.removeView(it) } }
        bubble?.let { runCatching { wm.removeView(it) } }
        vd?.release(); reader?.close(); projection?.stop()
        super.onDestroy()
    }
}
